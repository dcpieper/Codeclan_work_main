from models.order import *



order1 = Order("Ainsley Harriot", "16/11/22", "Half Life 2 Poster", 5)
order2 = Order("The Big Man", "27/1/23", "Mass Effect Poster", 3)
order3 = Order("Rupert Gonzalez", "12/2/22", "The Legend of Zelda: Ocarina of Time", 2)
orders = [order1, order2, order3]
