class Order():

    def __init__(self,customer_name, order_date, title, quantity):
        self.customer_name = customer_name
        self.order_date = order_date
        self.title = title
        self.quantity = quantity