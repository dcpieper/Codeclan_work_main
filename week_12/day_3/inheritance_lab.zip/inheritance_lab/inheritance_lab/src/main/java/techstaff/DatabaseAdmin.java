package techstaff;

import staff.Employee;

public class DatabaseAdmin extends Employee {

    public DatabaseAdmin(String name, String ni, double salary){
        super(name, ni, salary);
    }
}
